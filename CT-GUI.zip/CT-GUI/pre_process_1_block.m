%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%preprocessing 1 block case
%this script will preapre the data to the same preprocessing as used in the
%calibration set

test_data = test_original;
if chp1==2
    test_data{1,1} = preprocesspt(test_data{1,1},chp1,win_p1,pol_p1);%block 1 pre-processing start here
    X_ref = preprocesspt(x1,chp1,win_p1,pol_p1);
else
    test_data{1,1} = preprocesspt(test_data{1,1},chp1);
    X_ref = preprocesspt(x1,chp1);
end

if chc1 == 4 % special step for MSC correction
    test_data{1,1} = corr_msc(test_data{1,1},mean(X_ref));
elseif chc1 == 8 % special step for vsn application
    test_data{1,1} = vsn(test_data{1,1}, res1);
else
    test_data{1,1} = correctionpt(test_data{1,1},chc1);
end

if chn1==4
test_data{1,1} = derivativept(test_data{1,1},chn1,win_d1,pol_d1,der_d1);
else
test_data{1,1} = derivativept(test_data{1,1},chn1);    
end
clear X_ref;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%