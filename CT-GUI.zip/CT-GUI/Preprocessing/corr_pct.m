function [X_corr] = corr_pct(x);
% For smoothing, rem_PCs could be 6:30
% To use on xcal : [xcf, ld] = corr_pct(xc, 6:30);
% To use on xtest : xtf = corr_pct(xt, ld);
rem_PC = 6:30;

    
% Singular Value Decomposition of X

[u,s,v] = svd(x);
ld = v;
ld(:,rem_PC)=[];


% Rebuild filtered X
X_corr = x*ld*ld';