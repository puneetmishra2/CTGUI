function X_corr = corr_rnv(X0);
Prct = 10;
[n, p] = size(X0);
% Row robust center
pXr = prctile(X0',Prct,1)';
Xr_Cent= X0-pXr*ones(1,p);
% Row robust standardize
iqrXr = abs(prctile(X0',Prct,1)'-prctile(X0',100-Prct,1)');
X_corr = Xr_Cent./(iqrXr*ones(1,p));