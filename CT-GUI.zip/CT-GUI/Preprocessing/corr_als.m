function [Xcorr,bl] = corr_als(X0, lambda, q, maxit)
% ALS baseline removal
[n,m] = size(X0);
% Each spectrum of X0 processed iteratively
for i=1:n
x=X0(i,:)';
% compute Delta
D = diff(speye(m), 2);
% initialize the weights
w = ones(m, 1);
w0=w;
for it = 1:maxit
% solve the minimization
W = spdiags(w, 0, m, m);
C = chol(W + lambda * (D' * D));
z = C \ (C' \ (w .* x));
% update the weights
w = q * (x > z) + (1 - q) * (x < z);
% calculate the convergence criterion
fit=sum(abs(w0-w));
if fit<1e-10
break;
end;
w0=w;
end
bl(i,:)=z';
end;
Xcorr=X0-bl;