function X_corr = corr_msc(X0, Xref);
% Xref: reference spectrum ; default is mean of X
if(nargin==1)
Xref=mean(X0);
end;
[n,p]=size(X0);
for i=1:n
pf = polyfit(Xref,X0(i,:),1);
% finds the coefficients of a polynomial pf(x) of degree '1'
% that fits the data by least-squares fit.
X_corr(i,:)=(X0(i,:)-pf(2)*ones(1,p))./(pf(1)*ones(1,p));
end;