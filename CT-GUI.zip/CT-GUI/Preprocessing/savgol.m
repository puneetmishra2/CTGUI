function [y_hat,D]= savgol(y,width,order,deriv)
%SAVGOL Savitsky-Golay smoothing and differentiation.
%  Inputs are the matrix of ROW vectors to be smoothed (y),
%  and the optional variables specifying the number of points in
%  filter (width), the order of the polynomial (order), and the
%  derivative (deriv).
%
%  The outputs are the matrix of smoothed and differentiated ROW
%  vectors (y_hat) and the matrix of coefficients (cm) which can
%  be used to create a new smoothed/differentiated matrix,
%  i.e. y_hat = y*cm.
%
%  If number of points, polynomial order and derivative are not
%  specified, they are set to 15, 2 and 0, respectively.
%
%Example: if (y) is a 5 by 100 matrix then savgol(y,11,3,1)
%  gives a 5 by 100 matrix of first-derivative row vectors
%  resulting from a 11-point cubic Savitzky-Golay smooth of
%  each row of (y).
%
%I/O: [y_hat,cm] = savgol(y,width,order,deriv);
%I/O: savgol demo
%
%See also: BASELINE, BASELINEW, DERESOLV, LAMSEL, MSCORR, POLYINTERP, SAVGOLCV, STDFIR, WLSBASELINE

%Licensee shall not re-compile, translate or convert "M-files" contained
% in PLS_Toolbox for use with any software other than MATLAB�, without
% written permission from Eigenvector Research, Inc.
% Sijmen de Jong Unilever Research Laboratorium Vlaardingen Feb 1993
% Modified by Barry M. Wise 5/94
%         ***   Further modified, 1998-03, Martin Andersson
%         ***   Adjusting the calcn. of the bulk data.
%         ***   Based on calcn. of a sparse derivative matrix (D)
% JMS 10/07/02 -added basic dataset support
%   -added test for width too big
% JMS 12/02 -added "useexcluded" support (= don't use polyinterp w/excluded)
% JMS 1/20/03 -made "so few variables" a hard error
% JMS 3/2/04 -made "useexcluded" default as 'true'

% if nargin == 0; y = 'io'; end
% varargin{1} = y;
% if ischar(varargin{1});
%   options = [];
%   options.useexcluded = 'true';
%   if nargout==0; clear y_hat; evriio(mfilename,varargin{1},options); else; y_hat = evriio(mfilename,varargin{1},options); end
%   return; 
% end
% 
% options = savgol('options');
[m,n] = size(y);
y_hat = y;
if n<6;
  error('Unable to operate on so few variables')
end

% set default values: 15-point quadratic smooth
if nargin<4
  deriv= 0;
end
if nargin<3
  order= 2; 
end
if nargin<2
  width=min(15,floor(n/2)); 
end
% In case of input error(s) set to reasonable values
w = max( 3, width+1-mod(width,2) );
if w ~= width
  s = sprintf('Width must be >= 3 and odd. Changed to %g',w);
  disp(s)
  width = w;
end
w = min( width, floor(n/2)-1+mod(floor(n/2),2) );
if w ~= width
  s = sprintf('Width must be < 1/2 # of variables. Changed to %g',w);
  disp(s)
  width = w;
end
o = min([max(0,round(order)),5,w-1]);
if o ~= order
  s = sprintf('Order must be <= width -1 and <= 5. Changed to %g',o);
  disp(s)
end
d = min(max(0,round(deriv)),o);
if d ~= deriv
  s = sprintf('Deriviative must be <= order. Changed to %g',d);
  disp(s)
end

if isa(y,'dataset') &  n~=length(y.includ{2}) & strcmp(lower(options.useexcluded),'false');
  %dataset with excluded variables, use polyinterp
  x          = 1:n;
  y_hat      = polyinterp(x,y,x,w,o,d);
  wasdataset = 0;   %don't try reinserting into dataset, polyinterp does it for us
else
  if isa(y,'dataset')
    wasdataset = 1;
    origy      = y;
    y          = y.data;
  else
    wasdataset = 0;
  end
  
%   if mdcheck(y);
%     %missing data? use polyinterp
%     x     = 1:n;
%     y_hat = polyinterp(x,y,x,w,o,d);
%   else
    %fast case! do fast SavGol fit
    %------------------
    
    p = (w-1)/2;
    % Calculate design matrix and pseudo inverse
    x = ((-p:p)'*ones(1,1+o)).^(ones(size(1:w))'*(0:o));
    weights = x\eye(w);
    % Smoothing and derivative for bulk of the data
    coeff=prod(ones(d,1)*[1:o+1-d]+[0:d-1]'*ones(1,o+1-d,1),1);
    D=spdiags(ones(n,1)*weights(d+1,:)*coeff(1),p:-1:-p,n,n);
    % Smoothing and derivative for tails 
    w1=diag(coeff)*weights(d+1:o+1,:);
    D(1:w,1:p+1)=[x(1:p+1,1:1+o-d)*w1]'; 
    D(n-w+1:n,n-p:n)=[x(p+1:w,1:1+o-d)*w1]';
    % Operate on y using the filtering/derivative matrix, D
    y_hat=y*D;
    
    %------------------
  end
end

% if wasdataset       %replace modified data back into original dataset and return
%   origy.data = y_hat;
%   y_hat      = origy;



