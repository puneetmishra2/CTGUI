function ynew=savgol(varargin)

if nargin==4
    y=varargin{1}; 
    width=varargin{2}; 
    order=varargin{3}; 
    deriv=varargin{4};
elseif nargin==3
    y=varargin{1}; 
    width=varargin{2}; 
    order=varargin{3}; 
    deriv=0;
elseif nargin==2
    y=varargin{1}; 
    width=varargin{2}; 
    order=2; 
    deriv=0;    
elseif nargin==1
    y=varargin{1}; 
    width=7; 
    order=2; 
    deriv=0;
end

[r,c] = size(y);
ynew=y;

polord=min([max(0,round(order)),width-1]);
der = min(max(0,round(deriv)),polord);


hpoints = (width-1)/2;

% Building the independent block and its pseudoinverse
X = repmat((-hpoints:hpoints)',1,1+polord).^repmat((0:polord), width,1);
A = ((X'*X)\X')';

% Calcuating the SG filter/derivative for almost all data
for i=hpoints+2:c-hpoints-1                              
  ynew(:,i) = y(:,i-hpoints:i+hpoints)*(prod(1:der)*A(:,der+1));      
end

% SG smoothing/derivative for the tails
A = [y(:,1:width); y(:,c-width+1:c)]*A;  
for i=1:der
  A = A(:,2:polord+2-i)*diag(1:polord+1-i); % or its d'th derivative
end
ynew(:,1:hpoints+1) = A(1:r,:)*X(1:hpoints+1,1:1+polord-der)'; 
ynew(:,c-hpoints:c) = A(r+(1:r),:)*X(hpoints+1:width,1:1+polord-der)';