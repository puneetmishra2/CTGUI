function model = cross_val_lda(varargin)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%Default options can be obtained by writing: 
%           opt=cross_val_lda('options'); 

if nargin==1 && strcmp(varargin{1}, 'options')
    model.cvtype='syst123';
    model.cvsegments=5;
    return

elseif nargin==3
    X=varargin{1};
    cl=varargin{2};
    opt=varargin{3};
end

cvtype=opt.cvtype;
segments=opt.cvsegments;

if size(cl,1)==1
    cl=cl';
end


ntot=size(X,1);

if strcmp(cvtype, 'loo')  %Loo cross-validation corresponds to syst123 with N segments
    cvtype='syst123';
    segments=ntot;
end




for j=1:segments %Beginning of the crossvalidation loop
    
    switch cvtype
        case 'syst123'    %venetian blind cross-validation
            t=j:segments:ntot; %Calibration set
            m=1:ntot; m(t)=[]; %Validation set
            
        case 'syst111'    %contiguous blocks
            ns=ceil(ntot./segments);  %number of samples in each group
            if j==segments
                t=(j-1)*ns+1:ntot; %Validation set
            else
                t=(j-1)*ns+1:j*ns; %Calibration set
            end
            m=[1:(j-1)*ns ns*j+1:ntot]; %camp. nel set di calib.
    end
    
    
        Xm= X(m,:);
        Xt= X(t,:);
        clm=cl(m,:);
        clt=cl(t,: );
        
    overall_accuracy(1,1:20)=0;
    
    for nn=1:20
        mdl = fitcdiscr(Xm(:,1:nn),clm);
        pred = predict(mdl,Xt(:,1:nn));
        overall_accuracy(1,nn) = sum(clt-pred == 0)/size(clt,1);
        
    end
    
end

model.accuracy = overall_accuracy;
end

