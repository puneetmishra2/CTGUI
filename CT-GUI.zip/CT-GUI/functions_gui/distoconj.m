%function cl = distoconj(cld);
% passe du codage disjonctif (nclasses colonnes) au codage conjonctif 
% (no de classe sur une colonne)
% 
% cld : vecteur de degres d'appartenance (0 1) aux classes.
% cl : vecteur de no classes en sortie
%
% cette fonction accepte des degres d'appartenance non booleens. Elle attribue la classe
% grace au maximum du degre d'appartenance ....

function cl = distoconj(cld);

if size( cld, 2) > 1
    [mx,cl] = max(cld');
    cl = cl';
else
    cl = cld;
end;
