function model = cross_val_mlr(varargin)
%Function to run the cross validation on the mlr model for comdim based
%regression

%Default options can be obtained by writing: 
%           opt=cross_val_mlr('options'); 

if nargin==1 && strcmp(varargin{1}, 'options')
    model.cvtype='syst123';
    model.cvsegments=5;
    return

elseif nargin==3
    X=varargin{1};
    Y=varargin{2};
    opt=varargin{3};
end

cvtype = opt.cvtype;
segments = opt.cvsegments;

ntot=size(X,1);
ntot2=size(X,2);

if strcmp(cvtype, 'loo')  %Loo cross-validation corresponds to syst123 with N segments
    cvtype='syst123';
    segments=ntot;
end


rmsecv = zeros(ntot2,1);
rmsec = zeros(ntot2,1);


for j=1:segments %Beginning of the crossvalidation loop
    
    switch cvtype
        case 'syst123'    %venetian blind cross-validation
            t=j:segments:ntot; %Calibration set
            m=1:ntot; m(t)=[]; %Validation set
            
        case 'syst111'    %contiguous blocks
            ns=ceil(ntot./segments);  %number of samples in each group
            if j==segments
                t=(j-1)*ns+1:ntot; %Validation set
            else
                t=(j-1)*ns+1:j*ns; %Calibration set
            end
            m=[1:(j-1)*ns ns*j+1:ntot]; %camp. nel set di calib.
    end
        
    
        Xm=X(m,:);
        Xt=X(t,:);
        Ym=Y(m,:);
        Yt=Y(t,:);
    
    for nn=1:ntot2
        sm=fitlm(Xm(:,1:nn), Ym);
        predt = predict(sm,Xt(:,1:nn));
        predc = predict(sm,Xm(:,1:nn));
        rest = Yt-predt;
        resm = Ym-predc;
        rmsecv(nn)=rmsecv(nn) + sum(sum((rest).^2));
        rmsec(nn)=rmsec(nn) + sum(sum((resm).^2));
    end
    
end


rmsecv=sqrt(rmsecv./ntot);
rmsec=sqrt(rmsec./ntot);

model.rmsecv = rmsecv;
model.rmsec = rmsec;


end

