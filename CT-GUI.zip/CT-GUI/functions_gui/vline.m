function vline(x)

var  = '-r';

[i,j] = size(x);

if i>1&&j>1
  error('Error')
elseif j>1
  x = x';
  i = j;
end

v = axis;

if ishold
  for ii=1:i
    plot([1 1]*x(ii,1),v(3:4),var);
  end
else
    
  hold on
  for ii=1:i
    plot([1 1]*x(ii,1),v(3:4),var);
  end
  hold off
  
end
