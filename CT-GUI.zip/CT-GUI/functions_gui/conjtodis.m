%function cld = conjtodis(cl,lbcl);
% passe du codage conjonctif (numero ou symbole de classe sur une colonne) en disjonctif
% (nclasses colonnes).
% cl : vecteur de numeros classes en entree
% lbcl : labels de classes (facultatif). Cf NB2 ci dessous
% cld : vecteur de degres d'appartenance (0 1) aux classes.
%
% NB1 cl peut etre une structure ou une matrice et contenir des nombres 
%    ou des chaines de caracteres ; lbcl doit etre du meme type que cl
%
% NB2 si lbcl est omis : 
%    - le nombre de colonnes de cld sera egal au nombre de labels
%    differents rencontres dans cl
%    - le numero de colonne de cld attribue a chaque classe correspondra au
%    numero d'ordre naturel du label (tri ascendant) 


function [cld,clname] = conjtodis(cl,lbcl);

if size( cl, 1 ) == 1
    cl = cl';
end;

if nargin==1
    [u,m,n] = unique(cl,'rows');
    nbcl = size(u,1);
else
    if size( lbcl, 1 ) == 1
        lbcl = lbcl';
    end;
    [u,m,n] = unique([lbcl;cl],'rows');
    nbcl = size(lbcl,1);
    n=n(nbcl+1:end,:);
end;

nbech = size(cl,1);

cld = zeros(nbech,nbcl);
for i=1:nbcl
   x=find(n==i);
   if ~isempty(x)
      cld(x,i)=1;
   end;
end;
clname=u;

