function [num,crbvar,z,t] = covsel(x,y,lv);
%covsel       - Selection of variable from covariance maximisation
%  [num,crbvar] = covsel(X,Y,lv)
%
% Input arguments
%================
%X: Matlab matrix n x p
%X : Matlab matrix n x q
%
%Output arguments
%================
%num    : number (rank) of selected variables
%crbvar : evolution of cumulated variance of X (first column) and Y (second one)
%
%Written by JM Roger, CEMAGREF, Montpellier
%


crbvar=zeros(lv,2);

[nx,px] = size(x);
[ny,py] = size(y);

if nx ~= ny
  error('Le nombre d''individus ne correspond pas')
end

lv = min( lv, rank(x) );

z=mncn(x);
t=auto(y);
%t=mncn(y);


% variance (inertie) totale
%vartot=[ trace(z'*z)        trace(t'*t)]; %SLOW
vartot=[ sum(sum(z.*z))     sum(sum(t.*t))];

for i=1:lv
    i;
    % recherche max de covariance
    
    %[cm,j] = max( diag( z'*t*t'*z ) ); %SLOW
    [cm,j] = max( sum( (z'*t).^2 ,2) );
    
    num(i)=j;

    v = z(:,j);
    
    % projection orthogonale des x et des y 
    z = z - v*v'*z/(v'*v);
       
    %crbvar(i,1) = ( vartot(1) - trace(z'*z)    )  / vartot(1); %SLOW
    crbvar(i,1) = ( vartot(1)-  sum(sum(z.*z)) ) / vartot(1);

    t = t - v*v'*t/(v'*v);

    %crbvar(i,2) = ( vartot(2) - trace(t'*t)    ) / vartot(2); %SLOW
    crbvar(i,2) = ( vartot(2) - sum(sum(t.*t)) ) / vartot(2);

end;



