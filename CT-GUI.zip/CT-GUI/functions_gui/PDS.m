
function [x1_pds,x2_pds,F,ba] = PDS(x1,x2,w)

P = size(x1,2);
wd2=floor(w/2);
F=zeros(P,P);
ba=zeros(1,P);
re=zeros(1,P);

for i=1:P
    pdsindx=max(i-wd2,1):min(i+wd2,P);
    Ri=zeros(size(x2,1),length(pdsindx));
    ri=Ri;
    Ri=x2(:,pdsindx);
    ri=x1(:,i);
    [~,~,~,~,bi,~]=plsregress(Ri,ri,2);
    re(i)=sqrt(sumsqr([ones(size(Ri,1),1),Ri]*bi-ri)/size(Ri,1));
    F(pdsindx,i) = bi(2:end);
    ba(i)=bi(1);
end

x1_pds = x1*F + repmat(ba,[size(x1,1),1]);

x2_pds = x2*F + repmat(ba,[size(x2,1),1]);
end