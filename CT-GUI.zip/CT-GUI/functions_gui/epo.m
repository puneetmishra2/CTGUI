function [proj,ld]=epo(d,npc);

%function [proj,ld]=epo(d,npc);
%
% epo estimates the subspace (npc dim) span by d and
% computes the projection matix on the space orthogonal to it.
%
% the matrix proj contains the projector to apply to the calibration data
% (no need to apply it on the test set).
%
%  proj : the projector
%  ld   : the basis of the removed subspace
%
% Example : if x contains the calibration spectra and d 
% contains those containing the influence factor effects :
%
% z = x * epo(d,3); contains the spectra corrected from a 3 dim space
%

[n,p]=size(d);

if npc==0
    proj=eye(p);
else
    if n == 1
        proj = eye(p) - d'*inv(d*d')*d;
    else
        npc = min( npc, rank(d) );
%        [sc,ld]=pca_old(d,0,[],npc);
        if n < p        
            [u,s,v]=svd( d*d' );
            v = d'*v;
        else
            [u,s,v]=svd( d'*d );
        end;
        ld = v(:,1:npc);
        proj = eye(p) - ld*inv(ld'*ld)*ld';
    end;
end;




